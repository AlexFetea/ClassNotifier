import pymysql
import time

def update_last_accessed(course_num):
        # Connect to the MySQL database
        db = pymysql.connect(host="class-script-db.cx9uwbwgodg3.us-east-1.rds.amazonaws.com",\
        user="Admin",password="class_script1234",database='class-script-db', port=3306 )

        cursor = db.cursor()

        # Get the current UNIX timestamp
        current_timestamp = time.time()

        # Update the LastAccessed value for the given course number
        cursor.execute(
            "UPDATE Courses SET LastAccessed = %s WHERE CourseNumber = %s;",
            (current_timestamp, course_num)
        )

        # Commit the changes and close the cursor and the connection
        db.commit()
        cursor.close()
        db.close()