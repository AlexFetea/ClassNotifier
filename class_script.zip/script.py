from selenium import webdriver
from selenium.webdriver.common.by import By
from twilio.rest import Client
import time
from get import get_data
from update_last_accessed import update_last_accessed


# Your Account SID from twilio.com/console
account_sid = "AC0700118230c7bd3986fbbebd59508b4a"
# Your Auth Token from twilio.com/console
auth_token = "2663acf21edf1af0bdba09ca8a94281b"



client = Client(account_sid, auth_token)

message = client.messages.create(
    to="+15408096998",
    from_="+12534005782",
    body="STARTED")

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
driver = webdriver.Chrome(options=chrome_options, executable_path=r'C:\Users\ahfet\Downloads\chromedriver_win32/chromedriver.exe')


website = "https://sisuva.admin.virginia.edu/psc/ihprd/UVSS/SA/s/WEBLIB_HCX_CM.H_CLASS_DETAILS.FieldFormula.IScript_Main?institution=UVA01&term=1238&class_nbr="

current_class_list = []
print("started")

try:
    while True:
        data = get_data()
        print(data)
        for course_num in data.keys():
            if course_num not in current_class_list:
                driver.execute_script(
                    "window.open('about:blank', '" + course_num + "');")
                driver.switch_to.window(course_num)
                print(course_num)
                driver.get(website + course_num)
                current_class_list.append(course_num)
            else:
                driver.switch_to.window(course_num)
                driver.refresh()


            elements = driver.find_elements(
                By.CSS_SELECTOR, "p.cx-MuiTypography-root.cx-MuiTypography-body1")


            is_open = False
            for element in elements:
                if element.text == "Open":
                    is_open = True

            if is_open:
                last = data[course_num]['LastAccessed']

                if (time.time() - last) > 1200:
                    message = client.messages.create(
                        to="+15408096998",
                        from_="+12534005782",
                        body=course_num + " is open. Enroll now!")
                    for phone_num in data[course_num]['PhoneNumbers']:
                        message = client.messages.create(
                            to=phone_num,
                            from_="+12534005782",
                            body=course_num + " is open. Enroll now!")
                update_last_accessed(course_num)
            else:
                print(course_num + " closed")
        time.sleep(60)
except Exception as e:
    print(e)
    message = client.messages.create(
        to="+15408096998",
        from_="+12534005782",
        body="Error: "+str(e))

